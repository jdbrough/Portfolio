// huffcode.cpp  SKELETON
// Glenn G. Chappell
// 2025-11-10
//
// For CS 411 Fall 2025
// Assignment 6, Exercise A
// Source for class HuffCode

#include "huffcode.hpp"  // for class HuffCode declaration
#include <string>
using std::string;
#include <unordered_map>
using std::unordered_map;


void HuffCode::setWeights(const unordered_map<char, int> & theweights)
{
    // TODO: WRITE THIS!!!
}


string HuffCode::encode(const string & text) const
{
    // TODO: WRITE THIS!!!
    return "";  // DUMMY
}


string HuffCode::decode(const string & codestr) const
{
    // TODO: WRITE THIS!!!
    return "";  // DUMMY
}

